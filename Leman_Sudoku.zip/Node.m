//
//  Node.m
//
//  Created by Eric Chown on 4/4/13.
// Modified by Zackery Leman on 11/20/13
//  Copyright (c) 2013 edu.bowdoin.cs210.chown. All rights reserved.
// Sets up a node object for the list.
//The only change from what you provided with us was forcing the data to be a NSMutableString



#import "Node.h"

@implementation Node
@synthesize next = _next;
@synthesize data = _data;

@end
